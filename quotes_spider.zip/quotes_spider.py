import tkinter as tk
import scrapy
import re
import random
import subprocess
import customtkinter
from scrapy.crawler import CrawlerProcess
from tkinter.scrolledtext import ScrolledText
from tkinter import Toplevel, Label
from tkinter import ttk
from urllib.parse import urlparse,parse_qs
from twisted.internet import reactor
 
 
def show_results(text):
    result_window = Toplevel(root)
    result_window.title("結果表示")
    result_label = Label(result_window, text=text, wraplength=600, justify="left")
    result_label.pack()
 
root = tk.Tk()
root.title("クローラー")
root.geometry("1500x500")
 
url_entry = tk.Entry(root, width=50)
url_entry.pack()
url_entry.insert(tk.END, "URLを入力してください")
 
# ドメイン入力用のエントリーフィールド
domain_entry = tk.Entry(root, width=50)
domain_entry.pack()
domain_entry.insert(tk.END, "ドメインを入力してください")
 
def on_domain_entry_focus(event):
    domain_entry.delete(0, tk.END)
 
domain_entry.bind('<FocusIn>', on_domain_entry_focus)
 
 
def on_entry_focus(event):
    url_entry.delete(0, tk.END)
 
url_entry.bind('<FocusIn>', on_entry_focus)
 
# チェックボックス変数を用意
checkbox_vars = [tk.IntVar() for _ in range(4)]
 
# チェックボックスを作成
checkbox_titles = ["タイトル", "URL", "キーワード", "パラメータ"]
checkboxes = []
 
for i, title in enumerate(checkbox_titles):
    checkbox = tk.Checkbutton(root, text=title, variable=checkbox_vars[i])
    checkbox.pack()
    checkboxes.append(checkbox)
 
 
 
 
# Treeviewウィジェットを作成
treeview = ttk.Treeview(root, columns=("タイトル", "URL", "キーワード", "パラメータ"))
treeview.pack()
 
# 列を追加
treeview.column('#0', width=0, stretch='no')
treeview.column("タイトル", width=400, anchor="center")
treeview.column("URL", width=500, anchor="center")
treeview.column("キーワード", width=300, anchor="center")
treeview.column("パラメータ", width= 200, anchor="center")
 
# ヘッダーを追加
treeview.heading("タイトル", text="タイトル")
treeview.heading("URL", text="URL")
treeview.heading("キーワード", text="キーワード")
treeview.heading("パラメータ", text="パラメータ")
 
class MyItem(scrapy.Item):
    parameter1 = scrapy.Field()
    parameter2 = scrapy.Field()
 
class NavigationSpider(scrapy.Spider):
    name = "quotes"
    start_urls = []
    allowed_domains = []
 
 
    def __init__(self, custom_domain=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if custom_domain:
            self.allowed_domains.append(custom_domain)
 
    def get_mbsd_code(self, response):
        # レスポンスからテキストを取得
        text = response.text
 
        # 正規表現を使用してMBSD{}と{}の中の英数字を抽出
        pattern = r'MBSD{(.*?)}'
        matches = re.findall(pattern, text)
        return matches
 
    def parse(self, response):
        title = response.xpath('//title/text()').get()
        website_url = response.url
 
        matches = self.get_mbsd_code(response)
         # パラメータを取得
        parsed_url = urlparse(response.url)
        param = parse_qs(parsed_url.query)
 
        selected_items = []
 
        if checkbox_vars[0].get() == 1:
            selected_items.append(title)
        else:
            selected_items.append("")
 
        if checkbox_vars[1].get() == 1:
            selected_items.append(website_url)
        else:
            selected_items.append("")
 
        if checkbox_vars[2].get() == 1:
            selected_items.append(matches)
        else:
            selected_items.append("")
 
        if checkbox_vars[3].get() == 1:
            selected_items.append(param)
        else:
            selected_items.append("")
 
        treeview.insert('', 'end', values=selected_items)
 
        links = response.css('a::attr(href)').extract()
        domain = domain_entry.get()  # ドメインをエントリーフィールドから取得
        for link in links:
            absolute_url = response.urljoin(link)
            parsed_url = urlparse(absolute_url)
            if not domain or parsed_url.netloc == domain:
                yield scrapy.Request(absolute_url, callback=self.parse)  # ここで再帰的にクロールします
           
   
    def start_crawling(self):
        urls = url_entry
        for url in urls:
            process = subprocess.Popen("scrapy runspider url_scraper.py -o output.csv", shell=True)
            process.wait()
        with open("output.csv", "r") as f:
            for line in f:
                print(line)
 
process = CrawlerProcess(settings={"DEPTH_LIMIT":3, "DOWNLOAD_TIMEOUT":5})
 
 
 
def set_start_url():
    start_url = url_entry.get()
    domain = domain_entry.get()
    if domain:
        NavigationSpider.allowed_domains = [domain]
        start_url = url_entry.get()
        if start_url:
            NavigationSpider.start_urls = [start_url]
            process.crawl(NavigationSpider, custom_domain=domain)
            process.start()
        else:
            treeview.delete(1.0, tk.END)
            treeview.insert(tk.END, "URLを入力してください。\n")
 
def display_result(text):
    show_results(text)
 
crawl_button = tk.Button(root, text="スクレイピングを開始", command=set_start_url,bg="skyblue")
crawl_button.pack()
 
 
 
lst_fortune = ["凶","末吉","小吉","中吉","吉","大吉！"]  #運勢リスト
 
#--運勢Noをランダムに選択し、ラベルに運勢を表示
def changeText():
    i = random.choice(lst_fortune)  #ランダムな値を取得
    lb_value['text'] = i
 
bt_disp=tk.Button(text="今日のあなたの運勢は？", command=changeText)  #ボタン作成
lb_value=tk.Label(text="")  #ラベル作成
 
bt_disp.pack()  #ボタン配置
lb_value.pack()  #ラベル配置
 
root.mainloop()